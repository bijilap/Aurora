

import java.sql.*;

public class DatabaseSetup {
	
	public void setup() {
		
		DatabaseConfig dbc = new DatabaseConfig();
		Connection conn = null;
		Statement stmt = null;
		
		try{
			//Register JDBC driver
			Class.forName(dbc.getDriver());
			System.out.println("Connecting to database...");
			conn = DriverManager.getConnection(dbc.getURL(), dbc.getUser(), dbc.getPassword());
	
			//Execute a query
			System.out.println("Creating database...");
			stmt = conn.createStatement();
	      
			String sql = "CREATE DATABASE "+dbc.getDatabase();
			stmt.executeUpdate(sql);
			System.out.println("Database created successfully...");
	      
		}
		catch(SQLException se){
	      //Handle errors for JDBC
	      se.printStackTrace();
		}
		catch(Exception e){
	      //Handle errors for Class.forName
	      e.printStackTrace();
		}
		finally{
	      //finally block used to close resources
	      try{
	         if(stmt!=null)
	            stmt.close();
	      }
	      catch(SQLException se2){
	      }
	      try{
	         if(conn!=null)
	            conn.close();
	      }
	      catch(SQLException se){
	         se.printStackTrace();
	      }
	   }
		
	   Connection con = DatabaseConnect.connectToDB();
	   try {
		  Statement cstmt = con.createStatement();
	      String sql = 	 "CREATE TABLE ACTIVITY_PREFERENCE ("
	    		   		 + "USERID BIGINT NOT NULL, "
	    		   		 + "ITEMID BIGINT NOT NULL, "
	    		   		 + "RATING FLOAT NOT NULL, "
	    		   		 + "PRIMARY KEY (USERID, ITEMID),"
	    		   		 + "INDEX (USERID), "
	    		   		 + "INDEX (ITEMID)"
	    		   		 + ")";
	    		 
	      cstmt.executeUpdate(sql);
	      System.out.println(sql);
	      
	      sql = "CREATE TABLE RESTAURANT_PREFERENCE ("
 		   		 + "USERID BIGINT NOT NULL, "
 		   		 + "ITEMID BIGINT NOT NULL, "
 		   		 + "RATING FLOAT NOT NULL, "
 		   		 + "PRIMARY KEY (USERID, ITEMID),"
 		   		 + "INDEX (USERID), "
 		   		 + "INDEX (ITEMID)"
 		   		 + ")";
 		 
	      cstmt.executeUpdate(sql);
	      System.out.println(sql);
	      
	      
	      sql = "CREATE TABLE DISTANCE_COMPANY_PREFERENCE ("
	 		   		 + "USERID BIGINT NOT NULL, "
	 		   		 + "METRICID BIGINT NOT NULL, "
	 		   		 + "RATING FLOAT NOT NULL, "
	 		   		 + "PRIMARY KEY (USERID, METRICID),"
	 		   		 + "INDEX (USERID), "
	 		   		 + "INDEX (METRICID)"
	 		   		 + ")";
	 		 
		   cstmt.executeUpdate(sql);
		   System.out.println(sql);
	      
	      sql = "CREATE TABLE PERSONALITY ("
	 		   	+ "ID BIGINT NOT NULL, "
	 		   	+ "TITLE VARCHAR(20), "
	 		   	+ "PRIMARY KEY (ID),"
	 		   	+ "INDEX (ID)"
	 		   	+ ")";
	 		 
		  cstmt.executeUpdate(sql);
		  System.out.println(sql);
		  
		  sql = "CREATE TABLE ACTIVITY ("
			 	+ "ITEMID BIGINT NOT NULL, "
			 	+ "TITLE VARCHAR(30), "
			 	+ "PRIMARY KEY (ITEMID),"
			 	+ "INDEX (ITEMID)"
			 	+ ")";
			 		 
		  cstmt.executeUpdate(sql);
		  System.out.println(sql);

		  sql = "CREATE TABLE RESTAURANT ("
				 	+ "ITEMID BIGINT NOT NULL, "
				 	+ "TITLE VARCHAR(100), "
				 	+ "PRIMARY KEY (ITEMID),"
				 	+ "INDEX (ITEMID)"
				 	+ ")";
				 		 
		  cstmt.executeUpdate(sql);
		  System.out.println(sql);
		  
		  
	      cstmt.close();
	      
	   } catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	   }
	   DatabaseConnect.close();
	   
	}
}