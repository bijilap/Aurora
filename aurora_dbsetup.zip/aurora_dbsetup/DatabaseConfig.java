

public class DatabaseConfig implements DBConfig{
    
    public String getDriver(){
    	return dbDriver;
    }
    public String getURL(){
    	return dbUrl;
    }
    public String getDatabase(){
    	return dbDatabase;
    }
    public String getUser(){
    	return dbUser;
    }
    public String getHost(){
    	return dbHost;
    }
    public String getPort(){
    	return dbPort;
    }
    public String getPassword(){
    	return dbPassword;
    }
}
