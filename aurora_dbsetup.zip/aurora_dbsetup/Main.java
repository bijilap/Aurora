
public class Main {
	public static void main(String args[]){
		DatabaseSetup dbs = new DatabaseSetup();
		dbs.setup();
		
		ParseSurveyResults prs = new ParseSurveyResults();
		prs.parseSurveyResults();
	}
}
