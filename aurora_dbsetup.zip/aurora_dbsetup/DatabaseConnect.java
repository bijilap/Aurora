

import java.sql.DriverManager;
import java.sql.SQLException;

import java.sql.Connection;

public class DatabaseConnect {
	static DatabaseConfig dbc = new DatabaseConfig();
	static Connection con;
	
	public static Connection connectToDB(){
		try {
			Class.forName(dbc.getDriver());
			try {
				con = DriverManager.getConnection(dbc.getURL()+dbc.getDatabase(), dbc.getUser(), dbc.getPassword());
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}
	
	public static void close(){
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
