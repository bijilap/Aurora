

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class ParseSurveyResults {

	public  void parseSurveyResults(){
		try {
			Connection con = DatabaseConnect.connectToDB();
			BufferedReader br = new BufferedReader(new FileReader("data/Aurora_Full.txt"));
			String line = null;
			int userid = 1;
			while((line=br.readLine())!=null){
				String tokens[] = line.split("\t");
				
				for(int i=0;i<4;i++){
					String values = "";
					if(tokens[i+1].equals("1")){
						values += "("+userid+","+(2*i+1)+","+5+"),";
						values += "("+userid+","+(2*i+2)+","+1+")";
					}
					else{
						values += "("+userid+","+(2*i+1)+","+1+"),";
						values += "("+userid+","+(2*i+2)+","+5+")";
					}
					Statement stmt = con.createStatement();
					String sql = "INSERT INTO ACTIVITY_PREFERENCE VALUES"+values;
					stmt.executeUpdate(sql);
					sql = "INSERT INTO RESTAURANT_PREFERENCE VALUES"+values;
					stmt.executeUpdate(sql);
					System.out.println(sql);
					sql = "INSERT INTO DISTANCE_COMPANY_PREFERENCE VALUES"+values;
					stmt.executeUpdate(sql);
					System.out.println(sql);
					stmt.close();
				}
					
				for(int i=5, j=10; i<12; i++,j++){
					//bw.write(userid+","+j+","+words[i]+"\n");
					if(tokens[i].equals("Haven't visited")||tokens[i].equals("NA"))
						continue;
					Statement stmt = con.createStatement();
					String sql = "INSERT INTO ACTIVITY_PREFERENCE VALUES ("+userid+","+j+","+tokens[i]+")";
					stmt.executeUpdate(sql);
					System.out.println(sql);
					stmt.close();
				}
				
				for(int i=12, j=100; i<24; i++,j++){
					//bw.write(userid+","+j+","+words[i]+"\n");
					if(tokens[i].equals("Haven't visited")||tokens[i].equals("NA"))
						continue;
					Statement stmt = con.createStatement();
					String sql = "INSERT INTO RESTAURANT_PREFERENCE VALUES ("+userid+","+j+","+tokens[i]+")";
					stmt.executeUpdate(sql);
					System.out.println(sql);
					stmt.close();
				}
				
				/*
				 *  DISTANCE - Company preference
				 *  11 Alone
				 *  12 With Company
				 *  13 Price
				 *  14 Distance
				 */
				Statement stmt = con.createStatement();
				String values = "";
				if(tokens[24].equals("Alone")){
					values +="("+userid+",11,5)";
					values +=",("+userid+",12,1)";
				}
				else{
					values +="("+userid+",12,5)";
					values +=",("+userid+",11,1)";
				}
				if(tokens[25].equals("Distance")){
					values +=",("+userid+",13,1)";
					values +=",("+userid+",14,5)";
				}
				else if(tokens[25].equals("Price")){
					values +=",("+userid+",14,1)";
					values +=",("+userid+",13,5)";
				}
				else{
					values +=",("+userid+",13,5)";
					values +=",("+userid+",14,5)";
				}
				String sql = "INSERT INTO DISTANCE_COMPANY_PREFERENCE VALUES"+values;
				stmt.executeUpdate(sql);
				stmt.close();
				//for(int i = 0; i<tokens.length;i++)
				//	System.out.print(tokens[i]+",");
				System.out.println();
				userid++;
			}
			
			DatabaseConnect.close();
			br.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
